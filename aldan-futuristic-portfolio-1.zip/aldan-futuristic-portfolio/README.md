# ⚡ ALDAN.DEV — Futuristic Portfolio

Portfolio pribadi dengan tema **Futuristic Dark** (hitam, biru neon, dan cyan).

## ✨ Fitur
- Responsive untuk HP, tablet, dan desktop
- Navigasi mobile
- Hero section dengan animasi orbit CSS
- About, Skills, Projects, dan Contact
- Efek hover dan latar grid futuristik
- HTML, CSS, dan JavaScript murni

## 🚀 Cara menjalankan
1. Download atau clone repository ini.
2. Buka `index.html` di browser.
3. Untuk mengubah desain, edit `style.css`.

## ✏️ Bagian yang perlu kamu ubah
Buka `index.html`, lalu:
- Ganti tulisan `ALDAN` jika ingin memakai nama lain.
- Ganti `USERNAME` dengan username GitHub kamu.
- Ganti `emailkamu@example.com` dengan email kamu.
- Ganti link `https://github.com/` pada setiap project dengan link repository project milikmu.
- Ubah deskripsi dan daftar skill sesuai kemampuanmu.

## 🌐 Publish gratis dengan GitHub Pages
1. Buat repository bernama `USERNAME.github.io` (ganti USERNAME dengan username GitHub kamu).
2. Upload semua file dari folder ini ke bagian utama repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu tekan **Save**.
6. Tunggu proses selesai. Website akan tersedia di `https://USERNAME.github.io`.

---
Made with curiosity by Aldan.
